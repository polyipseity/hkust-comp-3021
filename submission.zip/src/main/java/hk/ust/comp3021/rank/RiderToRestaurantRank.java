package hk.ust.comp3021.rank;

import hk.ust.comp3021.Task;

public class RiderToRestaurantRank implements TaskRank {
  @Override
  public int compare(Task source, Task target) {
    return Double.compare(source.order.restaurant.location.distanceTo(source.rider.location),
        target.order.restaurant.location.distanceTo(target.rider.location));
  }
}
